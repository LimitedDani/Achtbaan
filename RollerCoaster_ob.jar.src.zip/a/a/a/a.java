package a.a.a;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.Configuration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitScheduler;

public final class a
  extends JavaPlugin
{
  public static a a;
  public Configuration b;
  public File c;
  private static a.a.a.a.b e;
  public HashMap d = new HashMap();
  
  public final void onEnable()
  {
    a = this;
    saveDefaultConfig();
    this.b = getConfig();
    this.c = new File(getDataFolder(), "config.yml");
    e = new a.a.a.a.b(this);
    try
    {
      new c();
      if (!c.a())
      {
        setEnabled(false);
        return;
      }
    }
    catch (IOException localIOException2)
    {
      IOException localIOException1;
      (localIOException1 = localIOException2).printStackTrace();
      setEnabled(false);
      return;
    }
    a();
    getCommand("rc").setExecutor(new a.a.a.b.a());
    Bukkit.getPluginManager().registerEvents(new a.a.a.b.b(), this);
    Bukkit.getScheduler().scheduleSyncRepeatingTask(a, new b(this), 20L, 1L);
  }
  
  public final void onDisable()
  {
    b();
  }
  
  public final void a()
  {
    Iterator localIterator = this.b.getStringList("attractions").iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      e.a(str + ".yml", "rollercoaster.yml");
      Object localObject2 = str + ".yml";
      Object localObject1 = (localObject1 = e).a((String)localObject2, null);
      localObject2 = new HashMap();
      List localList1 = ((a.a.a.a.a)localObject1).b("runs");
      for (int j = 0; j < localList1.size(); j++)
      {
        localList2 = ((a.a.a.a.a)localObject1).b("run." + ((String)localList1.get(j)).toString());
        ((HashMap)localObject2).put(((String)localList1.get(j)).toString(), localList2);
      }
      HashMap localHashMap = new HashMap();
      List localList2 = ((a.a.a.a.a)localObject1).b("spawns");
      for (int i = 0; i < localList2.size(); i++)
      {
        List localList3 = ((a.a.a.a.a)localObject1).b("spawn." + ((String)localList2.get(i)).toString());
        localHashMap.put(((String)localList2.get(i)).toString(), localList3);
      }
      d locald = new d(str, ((a.a.a.a.a)localObject1).a("run_command"), ((a.a.a.a.a)localObject1).a("run_permissions"), ((a.a.a.a.a)localObject1).a("spawn_command"), ((a.a.a.a.a)localObject1).a("spawn_permissions"), localHashMap, (HashMap)localObject2);
      this.d.put(str, locald);
    }
  }
  
  public final void b()
  {
    Iterator localIterator = this.d.values().iterator();
    while (localIterator.hasNext())
    {
      d locald;
      (locald = (d)localIterator.next()).h();
    }
    this.d.clear();
  }
  
  public final void c()
  {
    this.b = YamlConfiguration.loadConfiguration(this.c);
    b();
    a();
  }
}


/* Location:              C:\Users\daniq\Desktop\servertje\plugins\RollerCoaster_ob.jar!\a\a\a\a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
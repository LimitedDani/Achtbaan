package a.a.a.a;

import java.io.File;
import java.io.InputStream;
import java.util.List;
import java.util.Set;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

public final class a
{
  private int a;
  private b b;
  private File c;
  private FileConfiguration d;
  
  public a(InputStream paramInputStream, File paramFile, int paramInt, JavaPlugin paramJavaPlugin)
  {
    this.a = paramInt;
    this.b = new b(paramJavaPlugin);
    this.c = paramFile;
    this.d = YamlConfiguration.loadConfiguration(paramInputStream);
  }
  
  private Object c(String paramString)
  {
    return this.d.get(paramString);
  }
  
  private Object a(String paramString, Object paramObject)
  {
    return this.d.get(paramString, paramObject);
  }
  
  public final String a(String paramString)
  {
    return this.d.getString(paramString);
  }
  
  private String a(String paramString1, String paramString2)
  {
    return this.d.getString(paramString1, paramString2);
  }
  
  private int d(String paramString)
  {
    return this.d.getInt(paramString);
  }
  
  private int a(String paramString, int paramInt)
  {
    return this.d.getInt(paramString, paramInt);
  }
  
  private boolean e(String paramString)
  {
    return this.d.getBoolean(paramString);
  }
  
  private boolean a(String paramString, boolean paramBoolean)
  {
    return this.d.getBoolean(paramString, paramBoolean);
  }
  
  private void f(String paramString)
  {
    this.d.createSection(paramString);
  }
  
  private ConfigurationSection g(String paramString)
  {
    return this.d.getConfigurationSection(paramString);
  }
  
  private double h(String paramString)
  {
    return this.d.getDouble(paramString);
  }
  
  private double a(String paramString, double paramDouble)
  {
    return this.d.getDouble(paramString, paramDouble);
  }
  
  public final List b(String paramString)
  {
    return this.d.getList(paramString);
  }
  
  private List a(String paramString, List paramList)
  {
    return this.d.getList(paramString, paramList);
  }
  
  private boolean i(String paramString)
  {
    return this.d.contains(paramString);
  }
  
  private void j(String paramString)
  {
    this.d.set(paramString, null);
  }
  
  private void b(String paramString, Object paramObject)
  {
    this.d.set(paramString, paramObject);
  }
  
  private void a(String paramString1, Object paramObject, String paramString2)
  {
    if (!this.d.contains(paramString1))
    {
      this.d.set(this.b.a() + "_COMMENT_" + this.a, " " + paramString2);
      this.a += 1;
    }
    this.d.set(paramString1, paramObject);
  }
  
  private void a(String paramString, Object paramObject, String[] paramArrayOfString)
  {
    int i = (paramArrayOfString = paramArrayOfString).length;
    for (int j = 0; j < i; j++)
    {
      String str = paramArrayOfString[j];
      if (!this.d.contains(paramString))
      {
        this.d.set(this.b.a() + "_COMMENT_" + this.a, " " + str);
        this.a += 1;
      }
    }
    this.d.set(paramString, paramObject);
  }
  
  private void a(String[] paramArrayOfString)
  {
    this.b.a(this.c, paramArrayOfString);
    this.a = (paramArrayOfString.length + 2);
    paramArrayOfString = this;
    this.d = YamlConfiguration.loadConfiguration(paramArrayOfString.b.a(paramArrayOfString.c));
  }
  
  private void a()
  {
    this.d = YamlConfiguration.loadConfiguration(this.b.a(this.c));
  }
  
  private void b()
  {
    String str = this.d.saveToString();
    this.b.a(str, this.c);
  }
  
  private Set c()
  {
    return this.d.getKeys(false);
  }
}


/* Location:              C:\Users\daniq\Desktop\servertje\plugins\RollerCoaster_ob.jar!\a\a\a\a\a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
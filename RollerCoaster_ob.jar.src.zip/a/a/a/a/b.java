package a.a.a.a;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import org.bukkit.plugin.PluginDescriptionFile;
import org.bukkit.plugin.java.JavaPlugin;

public final class b
{
  private JavaPlugin a;
  
  public b(JavaPlugin paramJavaPlugin)
  {
    this.a = paramJavaPlugin;
  }
  
  public final a a(String paramString, String[] paramArrayOfString)
  {
    if (!(paramArrayOfString = b(paramString)).exists())
    {
      str = paramString;
      localb = this;
      a(str, null);
    }
    String str = paramString;
    b localb = this;
    return paramString = new a(a(localb.b(str)), paramArrayOfString, b(paramArrayOfString), this.a);
  }
  
  public final a a(String paramString)
  {
    paramString = null;
    String str1 = paramString;
    paramString = this;
    File localFile;
    String str2;
    if (!(localFile = b(str1)).exists())
    {
      str3 = str1;
      (str2 = paramString).a(str3, null);
    }
    String str3 = str1;
    return paramString = new a((str2 = paramString).a(str2.b(str3)), localFile, b(localFile), paramString.a);
  }
  
  private File b(String paramString)
  {
    if ((paramString.isEmpty()) || (paramString == null)) {
      return null;
    }
    if (paramString.contains("/"))
    {
      if (paramString.startsWith("/")) {
        paramString = new File(this.a.getDataFolder() + paramString.replace("/", File.separator));
      } else {
        paramString = new File(this.a.getDataFolder() + File.separator + paramString.replace("/", File.separator));
      }
    }
    else {
      paramString = new File(this.a.getDataFolder(), paramString);
    }
    return paramString;
  }
  
  public final void a(String paramString1, String paramString2)
  {
    if ((paramString1 = b(paramString1)).exists()) {
      return;
    }
    try
    {
      paramString1.getParentFile().mkdirs();
      paramString1.createNewFile();
      if ((paramString2 != null) && (!paramString2.isEmpty()))
      {
        paramString2 = paramString1;
        paramString1 = this.a.getResource(paramString2);
        try
        {
          paramString2 = new FileOutputStream(paramString2);
          byte[] arrayOfByte = new byte['Ѐ'];
          int i;
          while ((i = paramString1.read(arrayOfByte)) > 0) {
            paramString2.write(arrayOfByte, 0, i);
          }
          paramString2.close();
          paramString1.close();
        }
        catch (Exception localException)
        {
          (paramString2 = localException).printStackTrace();
        }
      }
      else {}
    }
    catch (IOException localIOException)
    {
      (paramString1 = localIOException).printStackTrace();
    }
  }
  
  private void c(String paramString)
  {
    a(paramString, null);
  }
  
  public final void a(File paramFile, String[] paramArrayOfString)
  {
    if (!paramFile.exists()) {
      return;
    }
    try
    {
      StringBuilder localStringBuilder1 = new StringBuilder("");
      BufferedReader localBufferedReader = new BufferedReader(new FileReader(paramFile));
      String str1;
      while ((str1 = localBufferedReader.readLine()) != null) {
        localStringBuilder1.append(str1 + "\n");
      }
      localBufferedReader.close();
      localStringBuilder1.append("# +----------------------------------------------------+ #\n");
      int i = (paramArrayOfString = paramArrayOfString).length;
      for (int j = 0; j < i; j++)
      {
        String str2;
        if ((str2 = paramArrayOfString[j]).length() <= 50)
        {
          int k = (50 - str2.length()) / 2;
          StringBuilder localStringBuilder2 = new StringBuilder(str2);
          for (int m = 0; m < k; m++)
          {
            localStringBuilder2.append(" ");
            localStringBuilder2.reverse();
            localStringBuilder2.append(" ");
            localStringBuilder2.reverse();
          }
          if (str2.length() % 2 != 0) {
            localStringBuilder2.append(" ");
          }
          localStringBuilder1.append("# < " + localStringBuilder2.toString() + " > #\n");
        }
      }
      localStringBuilder1.append("# +----------------------------------------------------+ #");
      (paramArrayOfString = new BufferedWriter(new FileWriter(paramFile))).write(e(localStringBuilder1.toString()));
      paramArrayOfString.flush();
      paramArrayOfString.close();
      return;
    }
    catch (IOException localIOException2)
    {
      IOException localIOException1;
      (localIOException1 = localIOException2).printStackTrace();
    }
  }
  
  public final InputStream a(File paramFile)
  {
    if (!paramFile.exists()) {
      return null;
    }
    try
    {
      int i = 0;
      String str = a();
      StringBuilder localStringBuilder = new StringBuilder("");
      BufferedReader localBufferedReader = new BufferedReader(new FileReader(paramFile));
      while ((paramFile = localBufferedReader.readLine()) != null) {
        if (paramFile.startsWith("#"))
        {
          paramFile = paramFile.replaceFirst("#", str + "_COMMENT_" + i + ":");
          localStringBuilder.append(paramFile + "\n");
          i++;
        }
        else
        {
          localStringBuilder.append(paramFile + "\n");
        }
      }
      paramFile = localStringBuilder.toString();
      paramFile = new ByteArrayInputStream(paramFile.getBytes(Charset.forName("UTF-8")));
      localBufferedReader.close();
      return paramFile;
    }
    catch (IOException localIOException2)
    {
      IOException localIOException1;
      (localIOException1 = localIOException2).printStackTrace();
    }
    return null;
  }
  
  private static int b(File paramFile)
  {
    if (!paramFile.exists()) {
      return 0;
    }
    try
    {
      int i = 0;
      BufferedReader localBufferedReader = new BufferedReader(new FileReader(paramFile));
      while ((paramFile = localBufferedReader.readLine()) != null) {
        if (paramFile.startsWith("#")) {
          i++;
        }
      }
      localBufferedReader.close();
      return i;
    }
    catch (IOException localIOException2)
    {
      IOException localIOException1;
      (localIOException1 = localIOException2).printStackTrace();
    }
    return 0;
  }
  
  private InputStream d(String paramString)
  {
    return a(b(paramString));
  }
  
  private String e(String paramString)
  {
    int i = 0;
    int j = 0;
    paramString = paramString.split("\n");
    StringBuilder localStringBuilder = new StringBuilder("");
    int k = (paramString = paramString).length;
    for (int m = 0; m < k; m++)
    {
      String str;
      if ((str = paramString[m]).startsWith(a() + "_COMMENT"))
      {
        if ((str = "#" + str.trim().substring(str.indexOf(":") + 1)).startsWith("# +-"))
        {
          if (j == 0)
          {
            localStringBuilder.append(str + "\n");
            i = 0;
            j = 1;
            continue;
          }
          if (j == 1)
          {
            localStringBuilder.append(str + "\n\n");
            i = 0;
            j = 0;
            continue;
          }
        }
        else
        {
          if (str.startsWith("# ' ")) {
            str = str.substring(0, str.length() - 1).replaceFirst("# ' ", "# ");
          } else {
            str = str;
          }
          if (i == 0) {
            localStringBuilder.append(str + "\n");
          } else if (i == 1) {
            localStringBuilder.append("\n" + str + "\n");
          }
          i = 0;
        }
      }
      else
      {
        localStringBuilder.append(str + "\n");
        i = 1;
      }
    }
    return localStringBuilder.toString();
  }
  
  public final void a(String paramString, File paramFile)
  {
    paramString = e(paramString);
    try
    {
      (paramFile = new BufferedWriter(new FileWriter(paramFile))).write(paramString);
      paramFile.flush();
      paramFile.close();
      return;
    }
    catch (IOException localIOException)
    {
      (paramFile = localIOException).printStackTrace();
    }
  }
  
  public final String a()
  {
    return this.a.getDescription().getName();
  }
  
  private static void a(InputStream paramInputStream, File paramFile)
  {
    try
    {
      paramFile = new FileOutputStream(paramFile);
      byte[] arrayOfByte = new byte['Ѐ'];
      int i;
      while ((i = paramInputStream.read(arrayOfByte)) > 0) {
        paramFile.write(arrayOfByte, 0, i);
      }
      paramFile.close();
      paramInputStream.close();
      return;
    }
    catch (Exception localException)
    {
      (paramFile = localException).printStackTrace();
    }
  }
}


/* Location:              C:\Users\daniq\Desktop\servertje\plugins\RollerCoaster_ob.jar!\a\a\a\a\b.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
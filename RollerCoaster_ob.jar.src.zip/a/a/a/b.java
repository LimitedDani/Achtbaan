package a.a.a;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Player;

final class b
  implements Runnable
{
  b(a parama) {}
  
  public final void run()
  {
    Iterator localIterator1 = this.a.d.values().iterator();
    while (localIterator1.hasNext())
    {
      d locald;
      HashMap localHashMap;
      Iterator localIterator2;
      Player localPlayer;
      if (!(locald = (d)localIterator1.next()).b)
      {
        localIterator2 = (localHashMap = locald.a()).keySet().iterator();
        while (localIterator2.hasNext())
        {
          localPlayer = (Player)localIterator2.next();
          if (((ArmorStand)localHashMap.get(localPlayer)).getPassenger() == null) {
            ((ArmorStand)localHashMap.get(localPlayer)).setPassenger(localPlayer);
          }
        }
      }
      else
      {
        localIterator2 = (localHashMap = locald.a()).keySet().iterator();
        while (localIterator2.hasNext())
        {
          localPlayer = (Player)localIterator2.next();
          if (((ArmorStand)localHashMap.get(localPlayer)).getPassenger() == null) {
            locald.a(localPlayer);
          }
        }
      }
    }
  }
}


/* Location:              C:\Users\daniq\Desktop\servertje\plugins\RollerCoaster_ob.jar!\a\a\a\b.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
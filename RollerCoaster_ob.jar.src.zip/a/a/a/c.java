package a.a.a;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import org.bukkit.Bukkit;
import org.bukkit.configuration.Configuration;

public final class c
{
  private final String a = "Mozilla/5.0";
  
  public static boolean a()
  {
    Object localObject1 = "https://daniquedejong.nl/check/modelride.php";
    (localObject1 = (HttpURLConnection)(localObject1 = new URL((String)localObject1)).openConnection()).setRequestMethod("POST");
    ((HttpURLConnection)localObject1).setRequestProperty("User-Agent", "Mozilla/5.0");
    ((HttpURLConnection)localObject1).setRequestProperty("Accept-Language", "en-US,en;q=0.5");
    Object localObject2 = InetAddress.getLocalHost();
    localObject2 = String.format("ip=%s&key=%s", new Object[] { ((InetAddress)localObject2).getHostAddress() + ":" + Bukkit.getPort(), a.a.b.getString("key") });
    ((HttpURLConnection)localObject1).setDoOutput(true);
    (localObject3 = new DataOutputStream(((HttpURLConnection)localObject1).getOutputStream())).writeBytes((String)localObject2);
    ((DataOutputStream)localObject3).flush();
    ((DataOutputStream)localObject3).close();
    localObject1 = new BufferedReader(new InputStreamReader(((HttpURLConnection)localObject1).getInputStream()));
    Object localObject3 = new StringBuffer();
    while ((localObject2 = ((BufferedReader)localObject1).readLine()) != null) {
      ((StringBuffer)localObject3).append((String)localObject2);
    }
    ((BufferedReader)localObject1).close();
    if (((StringBuffer)localObject3).toString().startsWith("allow")) {
      return a.a.b.getString("key").startsWith("ab_");
    }
    System.out.println("---");
    System.out.println("---");
    System.out.println("---");
    System.out.println("---");
    System.out.println("Your plugin isn't active anymore! What did i do wrong?");
    System.out.println("* You didn't insert the key, check the config.");
    System.out.println("* Your key has been deleted due abuse.");
    System.out.println("* For questions contact us at info@daniquedejong.nl.");
    System.out.println("---");
    System.out.println("---");
    System.out.println("---");
    System.out.println("---");
    return false;
  }
}


/* Location:              C:\Users\daniq\Desktop\servertje\plugins\RollerCoaster_ob.jar!\a\a\a\c.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
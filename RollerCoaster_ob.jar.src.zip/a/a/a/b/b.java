package a.a.a.b;

import a.a.a.a;
import a.a.a.d;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;

public final class b
  implements Listener
{
  private static void a(PlayerInteractAtEntityEvent paramPlayerInteractAtEntityEvent)
  {
    Player localPlayer = paramPlayerInteractAtEntityEvent.getPlayer();
    ArmorStand localArmorStand;
    if (((paramPlayerInteractAtEntityEvent.getRightClicked() instanceof ArmorStand)) && ((localArmorStand = (ArmorStand)paramPlayerInteractAtEntityEvent.getRightClicked()).getPassenger() == null))
    {
      Iterator localIterator = a.a.d.values().iterator();
      while (localIterator.hasNext())
      {
        d locald;
        if ((locald = (d)localIterator.next()).b().contains(localArmorStand))
        {
          if (locald.a)
          {
            paramPlayerInteractAtEntityEvent.setCancelled(true);
            localPlayer.teleport(localArmorStand);
            localArmorStand.setPassenger(localPlayer);
            locald.a(localPlayer, localArmorStand);
          }
          return;
        }
      }
    }
  }
  
  private static void a(PlayerArmorStandManipulateEvent paramPlayerArmorStandManipulateEvent)
  {
    ArmorStand localArmorStand;
    if (((paramPlayerArmorStandManipulateEvent.getRightClicked() instanceof ArmorStand)) && ((localArmorStand = paramPlayerArmorStandManipulateEvent.getRightClicked()).getPassenger() == null))
    {
      ArrayList localArrayList = new ArrayList();
      Iterator localIterator = a.a.d.values().iterator();
      while (localIterator.hasNext())
      {
        d locald = (d)localIterator.next();
        localArrayList.addAll(locald.c());
      }
      if (localArrayList.contains(localArmorStand)) {
        paramPlayerArmorStandManipulateEvent.setCancelled(true);
      }
    }
  }
}


/* Location:              C:\Users\daniq\Desktop\servertje\plugins\RollerCoaster_ob.jar!\a\a\a\b\b.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
package a.a.a.b;

import a.a.a.d;
import java.util.HashMap;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

public final class a
  implements CommandExecutor
{
  public final boolean onCommand(CommandSender paramCommandSender, Command paramCommand, String paramString, String[] paramArrayOfString)
  {
    if (paramCommand.getName().equalsIgnoreCase("rc"))
    {
      if ((paramArrayOfString.length == 1) && (paramArrayOfString[0].equalsIgnoreCase("reload")))
      {
        (paramCommand = a.a.a.a.a).b = YamlConfiguration.loadConfiguration(paramCommand.c);
        paramCommand.b();
        paramCommand.a();
        paramCommandSender.sendMessage(ChatColor.GREEN + "Reloading the configuration files... All carts are removed.");
        return false;
      }
      if (paramArrayOfString.length == 4)
      {
        if (a.a.a.a.a.d.containsKey(paramArrayOfString[0]))
        {
          if ((paramCommand = (d)a.a.a.a.a.d.get(paramArrayOfString[0])).d().equals(paramArrayOfString[1]))
          {
            if (((paramCommandSender instanceof Player)) && (!((Player)paramCommandSender).hasPermission(paramCommand.e()))) {
              return false;
            }
            if (paramCommand.a(Integer.parseInt(paramArrayOfString[2])))
            {
              if (paramCommand.b(paramArrayOfString[3]))
              {
                paramCommand.b(Integer.parseInt(paramArrayOfString[2]), paramArrayOfString[3]);
                paramCommandSender.sendMessage(paramArrayOfString[1] + " has been started");
              }
              else
              {
                paramCommandSender.sendMessage(ChatColor.RED + "No valid run id given.");
              }
            }
            else {
              paramCommandSender.sendMessage(ChatColor.RED + "This cart id doesn't exists.");
            }
            return false;
          }
          if (paramCommand.f().equals(paramArrayOfString[1]))
          {
            if (((paramCommandSender instanceof Player)) && (!((Player)paramCommandSender).hasPermission(paramCommand.g()))) {
              return false;
            }
            if (!paramCommand.a(Integer.parseInt(paramArrayOfString[2])))
            {
              if (paramCommand.a(paramArrayOfString[3]))
              {
                paramCommand.a(Integer.parseInt(paramArrayOfString[2]), paramArrayOfString[3]);
                paramCommandSender.sendMessage(paramArrayOfString[1] + " has been spawned");
              }
              else
              {
                paramCommandSender.sendMessage(ChatColor.RED + "No valid spawn id given.");
              }
            }
            else {
              paramCommandSender.sendMessage(ChatColor.RED + "This cart id already exists.");
            }
            return false;
          }
          paramCommandSender.sendMessage(ChatColor.RED + "This attraction doesn't exists.");
        }
      }
      else {
        paramCommandSender.sendMessage(ChatColor.RED + "Not all values given.");
      }
    }
    return false;
  }
}


/* Location:              C:\Users\daniq\Desktop\servertje\plugins\RollerCoaster_ob.jar!\a\a\a\b\a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
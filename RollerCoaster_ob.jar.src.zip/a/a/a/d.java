package a.a.a;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Server;
import org.bukkit.World;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitScheduler;
import org.bukkit.util.EulerAngle;

public final class d
{
  private String c;
  private String d;
  private String e;
  private String f;
  private String g;
  public boolean a;
  public boolean b;
  private HashMap h;
  private HashMap i;
  private HashMap j;
  private HashMap k;
  private HashMap l = new HashMap();
  
  public final void a(Player paramPlayer, ArmorStand paramArmorStand)
  {
    this.l.put(paramPlayer, paramArmorStand);
  }
  
  public final void a(Player paramPlayer)
  {
    this.l.remove(paramPlayer);
    a.a.d.put(this.c, this);
  }
  
  public final HashMap a()
  {
    return this.l;
  }
  
  public final ArrayList b()
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = this.j.values().iterator();
    while (localIterator.hasNext())
    {
      HashMap localHashMap = (HashMap)localIterator.next();
      localArrayList.add(localHashMap.get(Integer.valueOf(2)));
      localArrayList.add(localHashMap.get(Integer.valueOf(3)));
    }
    return localArrayList;
  }
  
  public final ArrayList c()
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = this.j.values().iterator();
    while (localIterator.hasNext())
    {
      HashMap localHashMap = (HashMap)localIterator.next();
      localArrayList.add(localHashMap.get(Integer.valueOf(1)));
    }
    return localArrayList;
  }
  
  public d(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, HashMap paramHashMap1, HashMap paramHashMap2)
  {
    this.c = paramString1;
    this.d = paramString2;
    this.e = paramString3;
    this.f = paramString4;
    this.g = paramString5;
    this.h = paramHashMap1;
    this.i = paramHashMap2;
    this.j = new HashMap();
    this.k = new HashMap();
  }
  
  public final boolean a(int paramInt)
  {
    return this.j.containsKey(Integer.valueOf(paramInt));
  }
  
  public final boolean a(String paramString)
  {
    return this.h.containsKey(paramString);
  }
  
  public final boolean b(String paramString)
  {
    return this.i.containsKey(paramString);
  }
  
  private String i()
  {
    return this.c;
  }
  
  public final String d()
  {
    return this.d;
  }
  
  public final String e()
  {
    return this.e;
  }
  
  public final String f()
  {
    return this.f;
  }
  
  public final String g()
  {
    return this.g;
  }
  
  private HashMap j()
  {
    return this.h;
  }
  
  private HashMap k()
  {
    return this.i;
  }
  
  public final void a(int paramInt, String paramString)
  {
    a((List)this.h.get(paramString), 0, paramInt);
  }
  
  public final void b(int paramInt, String paramString)
  {
    a((List)this.i.get(paramString), 0, paramInt);
  }
  
  private void a(List paramList, int paramInt1, int paramInt2)
  {
    for (paramInt1 = paramInt1; paramInt1 < paramList.size(); paramInt1++)
    {
      Object localObject1;
      if ((localObject1 = (String)paramList.get(paramInt1)).contains(":"))
      {
        if ((localObject1 = ((String)localObject1).split(":"))[0].equals("run"))
        {
          int m = paramInt2;
          Object localObject2 = localObject1[1];
          d locald = this;
          String str = localObject2.split(" ")[0];
          localObject2 = (localObject2 = localObject2.split(" ")[1]).split(",");
          Object localObject4;
          if (str.equals("spawn"))
          {
            locald.k.put(Integer.valueOf(m), Double.valueOf(Double.parseDouble(localObject2[8])));
            ArmorStand localArmorStand1;
            (localArmorStand1 = (ArmorStand)Bukkit.getWorld(localObject2[0]).spawnEntity(new Location(Bukkit.getWorld(localObject2[0]), Double.parseDouble(localObject2[1]), Double.parseDouble(localObject2[2]), Double.parseDouble(localObject2[3]), Integer.parseInt(localObject2[4]), 0.0F), EntityType.ARMOR_STAND)).setHelmet(new ItemStack(Material.valueOf(localObject2[6].toUpperCase()), 1, (byte)Integer.parseInt(localObject2[7])));
            localArmorStand1.setVisible(false);
            localArmorStand1.setBasePlate(false);
            localArmorStand1.setGravity(false);
            localArmorStand1.setCustomName(localArmorStand1.getUniqueId().toString());
            (localObject4 = new HashMap()).put(Integer.valueOf(1), localArmorStand1);
            int i1 = localObject2.length > 9 ? Integer.parseInt(localObject2[9]) : 2;
            for (int n = 0; n < i1; n++)
            {
              ArmorStand localArmorStand2;
              (localArmorStand2 = (ArmorStand)Bukkit.getWorld(localObject2[0]).spawnEntity(new Location(Bukkit.getWorld(localObject2[0]), Double.parseDouble(localObject2[1]), Double.parseDouble(localObject2[2]), Double.parseDouble(localObject2[3])), EntityType.ARMOR_STAND)).setBasePlate(false);
              localArmorStand2.setVisible(false);
              localArmorStand2.setGravity(false);
              localArmorStand2.setCustomName(localArmorStand2.getUniqueId().toString());
              ((HashMap)localObject4).put(Integer.valueOf(n + 2), localArmorStand2);
            }
            locald.j.put(Integer.valueOf(m), localObject4);
            locald.b(m);
            a.a.d.put(locald.c, locald);
          }
          Object localObject3;
          if (str.equals("move"))
          {
            (localObject4 = (ArmorStand)(localObject3 = (HashMap)locald.j.get(Integer.valueOf(m))).get(Integer.valueOf(1))).teleport(new Location(((ArmorStand)((HashMap)localObject3).get(Integer.valueOf(1))).getWorld(), ((ArmorStand)((HashMap)localObject3).get(Integer.valueOf(1))).getLocation().getX() + Double.parseDouble(localObject2[0]), ((ArmorStand)((HashMap)localObject3).get(Integer.valueOf(1))).getLocation().getY() + Double.parseDouble(localObject2[1]), ((ArmorStand)((HashMap)localObject3).get(Integer.valueOf(1))).getLocation().getZ() + Double.parseDouble(localObject2[2]), ((ArmorStand)((HashMap)localObject3).get(Integer.valueOf(1))).getLocation().getYaw() + Integer.parseInt(localObject2[3]), 0.0F));
            ((ArmorStand)localObject4).setHeadPose(((ArmorStand)localObject4).getHeadPose().add(-Double.parseDouble(localObject2[4]), 0.0D, localObject2.length == 6 ? Double.parseDouble(localObject2[5]) : 0.0D));
            locald.b(m);
            a.a.d.put(locald.c, locald);
          }
          Object localObject5;
          if (str.equals("eject"))
          {
            localObject3 = locald.b().iterator();
            while (((Iterator)localObject3).hasNext()) {
              if ((localObject4 = (ArmorStand)((Iterator)localObject3).next()).getPassenger() != null)
              {
                localObject5 = ((ArmorStand)localObject4).getPassenger();
                ((ArmorStand)localObject4).eject();
                ((Entity)localObject5).teleport(new Location(((ArmorStand)localObject4).getWorld(), ((ArmorStand)localObject4).getLocation().getX() + Double.parseDouble(localObject2[0]), ((ArmorStand)localObject4).getLocation().getY() + Double.parseDouble(localObject2[1]), ((ArmorStand)localObject4).getLocation().getZ() + Double.parseDouble(localObject2[2]), Integer.parseInt(localObject2[3]), Integer.parseInt(localObject2[4])));
              }
            }
          }
          if (str.equals("allow_sit"))
          {
            if (localObject2[0].equals("true")) {
              locald.a = true;
            } else {
              locald.a = false;
            }
            a.a.d.put(locald.c, locald);
          }
          if (str.equals("allow_leave"))
          {
            if (localObject2[0].equals("true")) {
              locald.b = true;
            } else {
              locald.b = false;
            }
            a.a.d.put(locald.c, locald);
          }
          if (str.equals("remove"))
          {
            localObject4 = (localObject3 = (HashMap)locald.j.get(Integer.valueOf(m))).values().iterator();
            while (((Iterator)localObject4).hasNext()) {
              (localObject5 = (ArmorStand)((Iterator)localObject4).next()).remove();
            }
            locald.k.remove(Integer.valueOf(m));
            locald.j.remove(Integer.valueOf(m));
            a.a.d.put(locald.c, locald);
          }
        }
        if (localObject1[0].equals("wait"))
        {
          paramInt1 = paramInt1;
          a.a.getServer().getScheduler().runTaskLater(a.a, new e(this, paramList, paramInt1, paramInt2), Integer.parseInt(localObject1[1]));
          return;
        }
      }
    }
  }
  
  private void a(String paramString, int paramInt)
  {
    String str = paramString.split(" ")[0];
    paramString = (paramString = paramString.split(" ")[1]).split(",");
    Object localObject2;
    if (str.equals("spawn"))
    {
      this.k.put(Integer.valueOf(paramInt), Double.valueOf(Double.parseDouble(paramString[8])));
      ArmorStand localArmorStand1;
      (localArmorStand1 = (ArmorStand)Bukkit.getWorld(paramString[0]).spawnEntity(new Location(Bukkit.getWorld(paramString[0]), Double.parseDouble(paramString[1]), Double.parseDouble(paramString[2]), Double.parseDouble(paramString[3]), Integer.parseInt(paramString[4]), 0.0F), EntityType.ARMOR_STAND)).setHelmet(new ItemStack(Material.valueOf(paramString[6].toUpperCase()), 1, (byte)Integer.parseInt(paramString[7])));
      localArmorStand1.setVisible(false);
      localArmorStand1.setBasePlate(false);
      localArmorStand1.setGravity(false);
      localArmorStand1.setCustomName(localArmorStand1.getUniqueId().toString());
      (localObject2 = new HashMap()).put(Integer.valueOf(1), localArmorStand1);
      int n = paramString.length > 9 ? Integer.parseInt(paramString[9]) : 2;
      for (int m = 0; m < n; m++)
      {
        ArmorStand localArmorStand2;
        (localArmorStand2 = (ArmorStand)Bukkit.getWorld(paramString[0]).spawnEntity(new Location(Bukkit.getWorld(paramString[0]), Double.parseDouble(paramString[1]), Double.parseDouble(paramString[2]), Double.parseDouble(paramString[3])), EntityType.ARMOR_STAND)).setBasePlate(false);
        localArmorStand2.setVisible(false);
        localArmorStand2.setGravity(false);
        localArmorStand2.setCustomName(localArmorStand2.getUniqueId().toString());
        ((HashMap)localObject2).put(Integer.valueOf(m + 2), localArmorStand2);
      }
      this.j.put(Integer.valueOf(paramInt), localObject2);
      b(paramInt);
      a.a.d.put(this.c, this);
    }
    Object localObject1;
    if (str.equals("move"))
    {
      (localObject2 = (ArmorStand)(localObject1 = (HashMap)this.j.get(Integer.valueOf(paramInt))).get(Integer.valueOf(1))).teleport(new Location(((ArmorStand)((HashMap)localObject1).get(Integer.valueOf(1))).getWorld(), ((ArmorStand)((HashMap)localObject1).get(Integer.valueOf(1))).getLocation().getX() + Double.parseDouble(paramString[0]), ((ArmorStand)((HashMap)localObject1).get(Integer.valueOf(1))).getLocation().getY() + Double.parseDouble(paramString[1]), ((ArmorStand)((HashMap)localObject1).get(Integer.valueOf(1))).getLocation().getZ() + Double.parseDouble(paramString[2]), ((ArmorStand)((HashMap)localObject1).get(Integer.valueOf(1))).getLocation().getYaw() + Integer.parseInt(paramString[3]), 0.0F));
      ((ArmorStand)localObject2).setHeadPose(((ArmorStand)localObject2).getHeadPose().add(-Double.parseDouble(paramString[4]), 0.0D, paramString.length == 6 ? Double.parseDouble(paramString[5]) : 0.0D));
      b(paramInt);
      a.a.d.put(this.c, this);
    }
    Object localObject3;
    if (str.equals("eject"))
    {
      localObject1 = b().iterator();
      while (((Iterator)localObject1).hasNext()) {
        if ((localObject2 = (ArmorStand)((Iterator)localObject1).next()).getPassenger() != null)
        {
          localObject3 = ((ArmorStand)localObject2).getPassenger();
          ((ArmorStand)localObject2).eject();
          ((Entity)localObject3).teleport(new Location(((ArmorStand)localObject2).getWorld(), ((ArmorStand)localObject2).getLocation().getX() + Double.parseDouble(paramString[0]), ((ArmorStand)localObject2).getLocation().getY() + Double.parseDouble(paramString[1]), ((ArmorStand)localObject2).getLocation().getZ() + Double.parseDouble(paramString[2]), Integer.parseInt(paramString[3]), Integer.parseInt(paramString[4])));
        }
      }
    }
    if (str.equals("allow_sit"))
    {
      if (paramString[0].equals("true")) {
        this.a = true;
      } else {
        this.a = false;
      }
      a.a.d.put(this.c, this);
    }
    if (str.equals("allow_leave"))
    {
      if (paramString[0].equals("true")) {
        this.b = true;
      } else {
        this.b = false;
      }
      a.a.d.put(this.c, this);
    }
    if (str.equals("remove"))
    {
      localObject2 = (localObject1 = (HashMap)this.j.get(Integer.valueOf(paramInt))).values().iterator();
      while (((Iterator)localObject2).hasNext()) {
        (localObject3 = (ArmorStand)((Iterator)localObject2).next()).remove();
      }
      this.k.remove(Integer.valueOf(paramInt));
      this.j.remove(Integer.valueOf(paramInt));
      a.a.d.put(this.c, this);
    }
  }
  
  private void b(int paramInt)
  {
    HashMap localHashMap = (HashMap)this.j.get(Integer.valueOf(paramInt));
    double d1 = ((Double)this.k.get(Integer.valueOf(paramInt))).doubleValue();
    paramInt = localHashMap.size() - 1;
    ArmorStand localArmorStand = (ArmorStand)localHashMap.get(Integer.valueOf(1));
    for (int m = 1; m < paramInt + 1; m++)
    {
      Object localObject1 = (ArmorStand)localHashMap.get(Integer.valueOf(m + 1));
      double d2 = (localArmorStand.getLocation().getYaw() + 360.0D / paramInt * m) * 3.141592653589793D / 180.0D;
      double d3 = d1 * Math.cos(d2);
      double d4 = d1 * Math.sin(d2);
      try
      {
        (localObject2 = localObject1.getClass().getMethod("getHandle", new Class[0])).setAccessible(true);
        (localObject2 = (localObject1 = ((Method)localObject2).invoke(localObject1, new Object[0])).getClass().getMethod("setLocation", new Class[] { Double.TYPE, Double.TYPE, Double.TYPE, Float.TYPE, Float.TYPE })).setAccessible(true);
        ((Method)localObject2).invoke(localObject1, new Object[] { Double.valueOf(localArmorStand.getLocation().getX() + d3), Double.valueOf(localArmorStand.getLocation().getY()), Double.valueOf(localArmorStand.getLocation().getZ() + d4), Float.valueOf(localArmorStand.getLocation().getYaw()), Float.valueOf(localArmorStand.getLocation().getPitch()) });
      }
      catch (Exception localException)
      {
        Object localObject2;
        (localObject2 = localException).printStackTrace();
      }
    }
  }
  
  public final void h()
  {
    Iterator localIterator = this.j.values().iterator();
    while (localIterator.hasNext())
    {
      Object localObject = (localObject = (HashMap)localIterator.next()).values().iterator();
      while (((Iterator)localObject).hasNext())
      {
        ArmorStand localArmorStand;
        (localArmorStand = (ArmorStand)((Iterator)localObject).next()).remove();
      }
    }
  }
}


/* Location:              C:\Users\daniq\Desktop\servertje\plugins\RollerCoaster_ob.jar!\a\a\a\d.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
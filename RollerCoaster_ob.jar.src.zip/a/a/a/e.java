package a.a.a;

import java.util.List;

final class e
  implements Runnable
{
  e(d paramd, List paramList, int paramInt1, int paramInt2) {}
  
  public final void run()
  {
    d.a(this.d, this.a, this.b + 1, this.c);
  }
}


/* Location:              C:\Users\daniq\Desktop\servertje\plugins\RollerCoaster_ob.jar!\a\a\a\e.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */